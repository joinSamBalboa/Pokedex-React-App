import React from 'react'
import { BrowserRouter, Switch, Route } from 'react-router-dom'

// Components
// Navbar
import Navbar from './components/Navbar'
// Home
import Home from './components/Home'
// PokemonList - List of pokemons
import PokemonList from './components/PokemonList'
// PokemonCards - individual pokemon by id, name, image, description. Maybe base if we have time
// RandomPokemon - Who's that pokemon?

// Image
// Loading/spinner pokemon inspired

// Function
// BrowserRouter
// Components
// Switch & routes

function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Switch>
          <Route exact path="/">
            <Home />
          </Route>
          <Route exact path="/list" >
            <PokemonList PokemonList={PokemonList}/>
          </Route>
        </Switch>
      </BrowserRouter>
    </>
  )
}


export default App
