import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {

  return (
    // link to pokemonTypeLists component
    // link to random pokemon generator
    <div className="navbar">
      <div className="container">
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/list">List</Link>
          </li>
          <li>
            <Link to="/random">Whos that Pokemon</Link>
          </li>
        </ul>
      </div>
    </div>


  )
}

export default Navbar