import React, { useState, useEffect } from 'react'
import axios from 'axios'

const PokemonList = () => {

  const [ pokemon , setPokemon ] = useState([])

  const [ hasError, setHasError ] = useState(false)


  useEffect(() => {
    const getPokemon = async () => {
      try {
        const { data } = await axios(' https://app.pokemon-api.xyz/pokemon/all')
        setPokemon(data)
      } catch (err){
        setHasError(true)
      }
    }
    getPokemon()
  }, [])


  return (
    <>
      Search:<input name="search"/>
      <select name="Type">
        <option value="All">All</option>
        <option value="Normal">Normal</option>
        <option value="Fire">Fire</option>
        <option value="Water">Water</option>
        <option value="Grass">Grass</option>
        <option value="Electric">Electric</option>
        <option value="Ice">Ice</option>
        <option value="Fighting">Fighting</option>
        <option value="Poison">Poison</option>
        <option value="Ground">Ground</option>
        <option value="Flying">Flying</option>
        <option value="Psychic">Psychic</option>
        <option value="Bug">Bug</option>
        <option value="Rock">Rock</option>
        <option value="Ghost">Ghost</option>
        <option value="Dark">Dark</option>
        <option value="Dragon">Dragon</option>
        <option value="Steel">Steel</option>
        <option value="Fairy">Fairy</option>
      </select>
      <div className='pokemon-list col-md-6'>
        {pokemon.length > 0 ?
      
          pokemon.map((item, i) => {
            return (
              <div key={i} className={item.type[0]} >
                <p value={item.id}>No.{item.id}</p>
                <p value={item.name.english}>{item.name.english}</p>
                <img src={item.thumbnail}/>
              </div>
            )
          })
      

          :
          hasError ?
            <p>Something went wrong!</p>
            :
            <p>Loading</p>
        }
      </div>
    </>
  )
}

export default PokemonList